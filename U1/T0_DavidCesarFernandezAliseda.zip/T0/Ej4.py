""" Convierta un número decimal en octal usando print() con formato de salida.

Dado: num = 8

Resultado: El número octal del número decimal 8 es 10 """

print("El número octal del número decimal 8 es", oct(8))
