""" Muestre el número flotante con 2 lugares decimales usando print()

Dado: num = 458.541315

Resultado: 458,54 """

print("%.2f" % 458.541315)
