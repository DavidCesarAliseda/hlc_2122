""" Muestre tres cadenas "Nombre", "Es", "Ignatius" como "Nombre ** Es ** Ignatius"

Utilice la print() función para formatear las palabras dadas en el formato mencionado. Muestre el separador ** entre cada cadena. """
print("Nombre", end="**")
print("es", end="**")
print("Ignatius")
