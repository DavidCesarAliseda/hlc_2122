# Acepte una lista de 5 números flotantes como entrada del usuario.
l = []

for i in range(5):
    l.append(input("Introduzca un numero: "))

print(l)
