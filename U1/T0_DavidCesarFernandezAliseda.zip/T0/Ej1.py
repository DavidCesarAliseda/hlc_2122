# Escriba un programa para aceptar dos números del usuario y calcular la multiplicación
n1 = input("Introduzca el primer numero: ")
n2 = input("Introduzca el segundo numero: ")

print("El resultado de ", n1, " por", n2, " es ", int(n1)*int(n2))
